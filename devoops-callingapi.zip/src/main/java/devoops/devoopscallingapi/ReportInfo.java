package devoops.devoopscallingapi;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class ReportInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    public ReportInfo() {}
    private String tmFc;
    private String tmSeq;

    public ReportInfo(Long id, String title, String tmFc, String tmSeq) {
        this.id=id;
        this.title=title;
        this.tmFc=tmFc;
        this.tmSeq=tmSeq;
    }
}
