package devoops.devoopscallingapi;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

@Controller
public class HomeController {

    @Autowired
    private ReportInfoRepository infoRepository;

    public interface ReportInfoRepository extends JpaRepository<ReportInfo,Long> {
    }

    @GetMapping("/api")
    public String index(){
        return "index";
    }

    @PostMapping("/api")
    public String load_save(@RequestParam("date") String date, Model model){
        String result = "";

        try {
            String requestDate = date;
            URL url = new URL("http://apis.data.go.kr/1360000/WthrWrnInfoService/getWthrWrnList?"
                    +"serviceKey=wi0Fe0N5C02cEenuZ7R%2Bj3vBrM9m9dV6dPGVZkHwbhdCMdThzXRetUoivRZDsvVgcj65TCbmVpba9lNOdXGbFg%3D%3D"+"&numOfRows=10&pageNo=1&"+ requestDate);
            BufferedReader bf = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
            result = bf.readLine();

            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject)jsonParser.parse(result);
            JSONObject Response = (JSONObject)jsonObject.get("Response");
            Long totalCount=(Long)Response.get("totalCount");

            JSONObject subResult = (JSONObject)Response.get("RESULT");
            JSONArray reportinfoArr = (JSONArray) Response.get("items");

            for(int i=0;i<reportinfoArr.size();i++){
                JSONObject tmp = (JSONObject)reportinfoArr.get(i);
                ReportInfo infoObj = new ReportInfo(i+(long)1, (String)tmp.get("title"),(String) tmp.get("tmFc"),(String) tmp.get("tmSeq"));
            }

            for(int i=0;i<reportinfoArr.size();i++){
                JSONObject tmp = (JSONObject)reportinfoArr.get(i);
                ReportInfo infoObj=new ReportInfo(i+(long)1, (String)tmp.get("title"),(String) tmp.get("tmFc"),(String) tmp.get("tmSeq"));
                infoRepository.save(infoObj);
            }

        }catch(Exception e) {
            e.printStackTrace();
        }
        return "redirect:/findname";
    }
}
