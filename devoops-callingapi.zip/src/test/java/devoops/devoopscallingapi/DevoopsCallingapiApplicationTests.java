package devoops.devoopscallingapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevoopsCallingapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
